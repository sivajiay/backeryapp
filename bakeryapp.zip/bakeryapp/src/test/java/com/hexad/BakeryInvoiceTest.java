package com.hexad;

import org.junit.Test;

import java.io.ByteArrayInputStream;

/**
 * @author  Sivaji Ay
 * Test Cases
 */
public class BakeryInvoiceTest {
    @Test
    public void test10VS5(){
        String testStr = "10 VS5";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void test14MB11(){
        String testStr = "14 MB11";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void test13CF(){
        String testStr = "13 CF";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void test10VS5Lowercase(){
        String testStr = "10 vs5";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void test14MB11Lowercase(){
        String testStr = "14 mb11";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void test13CFLowercase(){
        String testStr = "13 cf";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }

    @Test
    public void testWithInvalidQuantity(){
        String testStr = "1A CF";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void testWithInvalidCode(){
        String testStr = "13 CCF";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }
    @Test
    public void testWithInvalidCodeAndQuantity(){
        String testStr = "B2 CCF";
        String[] strArr = null;
        ByteArrayInputStream in = new ByteArrayInputStream(testStr.getBytes());
        System.setIn(in);
        BakeryInvoice.main(strArr);
        System.setIn(System.in);
    }


}
